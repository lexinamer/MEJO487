$(function(){
  console.log('scripts loaded');

});//close ready wrapper
