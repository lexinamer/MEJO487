$(document).ready(function(){
  console.log ('DOM loaded');

  // Set up any variables needed
  // Load the JSON data
      // Console log the data
      // Callbacks for logic and chart

  // Function to do logic
    // Set up a for loop to loop through the data
      // Push data to different arrays to prepare for chart

  // Function to build charts
    // Setting some default highchart actions
    // Lets set up the basics of a column chart
      // Chart Type
      // Title and Subtitle
      // Axises
      // Actual data plotting
      // Tooltip

});
