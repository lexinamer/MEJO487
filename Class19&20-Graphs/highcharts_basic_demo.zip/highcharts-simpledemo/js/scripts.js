$(document).ready(function(){
  console.log ('DOM loaded');

  //THE BASIC HIGHCHART PASTE JOB WITH HARD-CODED ARRAY
   Highcharts.chart('container', {
    chart: {
        type: 'bar'
    },
    title: {
        text: 'Fruit Consumption'
    },
    subtitle:{
      text: 'People freaking Love Fruit'
    },
    xAxis: {
        categories: ['Apples', 'Bananas', 'Oranges']//NOTICE THIS IS AN ARRAY
    },
    yAxis: {
        title: {
            text: 'Fruit eaten'
        }
    },
    series: [{
        name: 'Jane',//DELETE THIS AND SEE HOW THE CHART CHANGES
        data: [1, 0, 4]//HOVER OVER THE BARS TO SEE WHAT THESE NUMBERS REPRESENT
    }, {
        name: 'John',
        data: [5, 7, 3]
    }]//ADD ANOTHER OBJECT AND SEE HOW IT CHANGES
  });
});
