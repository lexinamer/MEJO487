$(document).ready(function(){
  console.log('scripts loaded');

  // Data will go here

  // One Min chart will go here

  // Five Min chart will go here

});//close ready wrapper
