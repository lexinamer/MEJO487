$(document).ready(function(){
  console.log('Scripts loaded');

})
