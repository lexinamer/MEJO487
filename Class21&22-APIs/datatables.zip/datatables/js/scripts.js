$(function(){
  console.log('scripts loaded');
  
});
