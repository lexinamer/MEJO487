$(document).ready(function(){
  console.log('scripts loaded');

  /*
  1. Build an HTML table using an AJAX call on the provided XML file (nobelprize.json). The JSON data shows all of the Nobel Prize winners since 2000.

  2. The table should have four columns:
      - Prize year
      - Prize category
      - Number of Prize laureates
      - Overall Motivation

  3. You will notice that the table is a bit messy; some of the prizes have no motivations. Clean this up with conditional logic in your code. If the prize has no motivation, print "General" in its place.
  */
});
