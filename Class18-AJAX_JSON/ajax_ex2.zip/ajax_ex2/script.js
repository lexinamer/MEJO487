$(document).ready(function(){

  // Set up Ajax Request

  // Console log the data and examine it

  // Pass the data to a function

  // Write a function to do all the work

  // Figure out what data you need and use it

});
