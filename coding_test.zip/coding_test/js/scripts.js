$(document).ready(function() {
  console.log('Ready to begin the test...');

});
